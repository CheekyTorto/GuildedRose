﻿USE [GildedRoseDB]
GO

/****** Object: Table [dbo].[ItemTable] Script Date: 2/12/2017 8:23:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

DROP TABLE [dbo].[ItemTable];


GO
CREATE TABLE [dbo].[ItemTable] (
    [item_Name]     VARCHAR (50) NOT NULL,
    [item_Category] VARCHAR (50) NOT NULL,
    [item_Sell_In]   VARCHAR (50) NOT NULL,
    [item_Quality]  VARCHAR (50) NOT NULL,
	[item_Date]  SMALLDATETIME NOT NULL
);


