﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GildedRose.Models.Abstract;
using GildedRose.Domain.Concrete;
using GildedRose.Models;

namespace GildedRose.Concrete
{
    public class EFDataModelRepository :IDataModelRepository
    {
        private EFDbContext context = new EFDbContext();

        public IQueryable<DataModel> DataModels
        {
            get { return context.DataModels; }
        }
        public void SaveDataModel(DataModel dataModel)
        {
            if (dataModel.item_Name == "")
            {
                context.DataModels.Add(dataModel);
            }
            else
            {
                DataModel dbEntry = context.DataModels.Find(dataModel.item_Name);
                if (dbEntry != null)
                {
                    dbEntry.item_Name = dataModel.item_Name;
                    dbEntry.item_Category = dataModel.item_Category;
                    dbEntry.item_Sell_In = dataModel.item_Sell_In;
                    dbEntry.item_Quality = dataModel.item_Quality;
                }
            }
            context.SaveChanges();

            }
        }
    }