﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GildedRose.Models;
using System.Data.Entity;

namespace GildedRose.Domain.Concrete
{
    public class EFDbContext : DbContext
    {
        public DbSet<DataModel> DataModels { get; set; }        
    }
}