﻿using GildedRose.Models;
using System.Linq;

namespace GildedRose.Concrete
{
    public interface IDataModelRepository
    {
        IQueryable<DataModel> DataModels { get; }
    }
}