﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GildedRose.Models;

namespace GildedRose.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour < 12 ? "Good morning" : "Hello";
            return View();
        }

        [HttpGet]
        public ViewResult DataModels()
        {
            return View();
        }

        [HttpPost]
        public ViewResult InventoryForm(DataModels inventoryResponse)
        {
            if (ModelState.IsValid)
            {
                return View("Inventory Updated", inventoryResponse);
            }
            else
            {
                return View();
            }
        }
        public ActionResult InventoryForm()
        {
            return View();
        }
        public ActionResult About()
        {
            ViewBag.Message = "Gilded Rose Description.";

            return View();
        }

        public ActionResult ListInventory()
        {
            return View();
        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Contact Us.";

            return View();
        }
    }
}