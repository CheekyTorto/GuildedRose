﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GildedRose.Models
{
    public class DataModel
    {
        public string item_Name { get; set; }    
        public string item_Category { get; set; } 
        public string item_Sell_In { get; set; }
        public string item_Quality { get; set; }
        public DateTime item_Date { get; set; }
    }
}