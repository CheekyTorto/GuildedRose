﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GildedRose.Models
{
    public class DataModels
    {
        [Required(ErrorMessage ="Please Enter a Name")]
        public string item_Name { get; set; }

        [Required(ErrorMessage = "Please Enter a Category")]
        public string item_Category { get; set; }

        [Required(ErrorMessage = "Please Enter the Sell In Value")]
        [RegularExpression("\\d+", ErrorMessage = "Please Enter a number between 10 and 99")]
        public string item_Sell_In { get; set; }

        [Required(ErrorMessage = "Please Enter the Quality Value")]
        [RegularExpression("\\d+", ErrorMessage = "Please Enter a number between 10 and 99")]
        public string item_Quality { get; set; }
        public DateTime item_Date { get; set; }


    }
}