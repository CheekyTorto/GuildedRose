﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GildedRose.Models;

namespace GildedRose.Models.Abstract
{
    public interface IDataModel
    {
        IQueryable<DataModel> DataModels { get; }

        void SaveItem(DataModels dataModel);
    }
}
